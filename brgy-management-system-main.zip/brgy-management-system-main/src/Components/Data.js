export const sexdata = ["Male", "Female"];

export const civilStatus = ["Single", "Married", "Divorced", "Widow", "Separated"];

export const selection = ["Yes", "No"];

export const housestatus = ["House Owner", "Renter", "Sharer"];

export const areas = [
  "Purok 1, Payawan 1",
  "Purok 2, Payawan 1",
  "Purok 3, Payawan 1",
  "Purok 4, Payawan 1",
  "Purok 5, Payawan 1",
  "Purok 6, Payawan 2",
  "Purok 7, Payawan 2",
  "Purok 8, Payawan 2",
  "Purok 9 Ilang-Ilang, Payawan 2",
  "Purok 10 Springville A, Payawan 2",
  "Purok 11 Springville B, Payawan 2",
  "Purok 11 Springville C, Payawan 2",
  "Purok 12 Macresia/Greens Homes, Payawan 2",
  "Purok 34 Muslim Community, Payawan 2",
  "Purok 17 Poblacion 2, CentralPoblacion",
  "Purok 18 Rivcor Poblacion, CentralPoblacion",
  "Purok 19 Tuazon Village, CentralPoblacion",
  "Purok 20 Poblacion 3, CentralPoblacion",
  "Purok 21 Airport Riverside, CentralPoblacion",
  "Purok 22 Holy Cross/Nembusco, CentralPoblacion",
  "Purok 29 Highway Bacud, Bacud",
  "Purok 30 Interior, Bacud",
  "Purok 31 Pangpang Riverside, Bacud",
  "Purok 32 Cortes, Bacud",
  "Purok 33, SanVicente",
  "Purok 33-A, SanVicente",
  "Purok 23, Looc",
  "Purok 24, Looc",
  "Purok 24-A, Looc",
  "Purok 25 Magbago, Looc",
  "Purok 26 GK/EXIT, Looc",
  "Purok 5, Bernadette",
  "Purok 14, Bernadette",
  "Purok 15, Bernadette",
  "Purok 16, Bernadette",
  "Purok 20, Bernadette",
  "Purok 27, Toril",
  "Purok 27-A, Toril",
  "Purok 28, Toril",
  "Purok 28-A, Toril",
];
